
PORT = 65432  # Port to listen on (non-privileged ports are > 1023)

LOCAL_HOST = "127.0.0.1"

HEADER_SIZE = 10
